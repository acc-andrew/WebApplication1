﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Request.Form["userid"] != null) &&
                (Request.Form["passwd"] != null)    )
            { 
                if((Request.Form["userid"] == "lccnet") && 
                    (Request.Form["passwd"] == "123456"))
                {
                    Response.Redirect("http://tw.yahoo.com/");
                }
                else
                {
                    if (Request.Form["userid"] != "lccnet")
                    {
                        _veri_userid.Text = "帳號錯誤！";
                    }
                    else
                    {
                        _veri_userid.Text = "";
                    }
                    if (Request.Form["passwd"] != "123456")
                    {
                        _veri_passwd.Text = "密碼錯誤！";
                    }
                    else
                    {
                        _veri_passwd.Text = "";
                    }
                    // Response.Redirect("http://www.google.com.tw/");
                }
            }// 
        }// Page_Load


    }
}