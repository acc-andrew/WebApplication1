﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class test2 : System.Web.UI.Page
    {
        int _userInp = 0;
        int _cmpInp = 0;
        Random _rndCpt;

        string[] result = new string[3] { "剪刀", "石頭", "布" };

        protected void Page_Load(object sender, EventArgs e)
        {/*
            if (_TextBoxAcc.Text == "lccnet" && _TextBoxAcc.Text == "123456")
            {
                Response.Redirect("http://tw.yahoo.com/");
            }
            else
            {
                Response.Redirect("http://www.google.com.tw/");
            }
            */
            _rndCpt = new Random((int)DateTime.Now.Millisecond);
            int niCptAnsOut = _rndCpt.Next(0, 3);
            if (niCptAnsOut == 0)
                _imageCpt.ImageUrl = "~/pics/scissor.jpg";
            else if (niCptAnsOut == 1)
                _imageCpt.ImageUrl = "~/pics/stone.jpg";
            else
                _imageCpt.ImageUrl = "~/pics/paper.jpg";

            /*
            Response.Write("Flush 之前</br>");
            Response.Flush();

            Response.Write("Flush 之後， ClearContent 之前</br>");
            Response.ClearContent();

            Response.Write("ClearContent 之後， End 之前</br>");
            Response.End();

            Response.Write("End 之後</br>");
            */
            /*
            Response.Write("9 * 9 乘法表 Web API");
            Response.Write("</br>");

            if ((Request.QueryString["rows"] != null) &&
                (Request.QueryString["cols"] != null))
            {
                int rows = int.Parse(Request.QueryString["rows"]);
                int cols = int.Parse(Request.QueryString["cols"]);

                // 9*9
                for (int row = 1; row < rows; row++)
                {
                    for (int col = 1; col < cols; col++)
                    {
                        string rowText, sResult = "";
                        int nResult = row * col;
                        sResult = nResult.ToString();
                        rowText = row.ToString() + " * " + col.ToString() + " = " + sResult.ToString();
                        Response.Write(rowText);
                        Response.Write(" , ");
                    }
                    Response.Write("</br>");
                }// for 
            }// if arguments exist
            */

            /*
            // != "" fail
            if ((Request.QueryString["height"] != null) &&
                (Request.QueryString["weight"] != null)) { 
                double ndheight = int.Parse(Request.QueryString["height"]);
                double ndweight = int.Parse(Request.QueryString["weight"]);
                ndheight /= 100.0;
                ndheight *= ndheight;
                ndweight /= ndheight;
                Label1.Text = ndweight.ToString();
                Response.Write("Server reponses text.");

                double ndBMI = ndweight / (ndweight * ndweight);
                Label1.Text = ndBMI.ToString();

            }
            */
        }// Load

        protected void Button_Click(object sender, EventArgs e)
        {
            if( (Request.Form["_TextBoxAcc"] != null) &&
                (Request.Form["_TextBoxPws"] != null))
            {
                if(Request.Form["_TextBoxAcc"] == "lccnet")
                {
                    if (Request.Form["_TextBoxPws"] == "123456")
                        Response.Redirect("http://tw.yahoo.com/");
                    else
                    {
                        PwsLabel1.Text = "密碼帳號輸入錯誤！";
                    }
                }
                else
                {
                    AccLabel.Text = "帳號輸入錯誤！";
                }
            }// 

        }// protected void Button_Click(object sender, EventArgs e)

        private void setCmpPic(int n)
        {
            if (n == 0)
                _imageCpt.ImageUrl = "~/pics/scissor.jpg";
            else if (n == 1)
                _imageCpt.ImageUrl = "~/pics/stone.jpg";
            else
                _imageCpt.ImageUrl = "~/pics/paper.jpg";

        }

        private void decideResult(int user, int niCptAnsOut)
        {
            string outText = "";
            string outUserInp = result[user];
            string outCmpInp = result[niCptAnsOut];

            outText = "你出 " + outUserInp;
            outText += "，電腦出 ";
            outText += outCmpInp;

            if (niCptAnsOut > _userInp)
            {
                if ((niCptAnsOut == 2) && (_userInp == 0)) {
                    outText += "：你贏了！";
                    Label_pssResult.Text = outText;
                }
                else {
                    outText += "：你輸了！";
                    Label_pssResult.Text = outText;
                }
            }
            else
            {
                if (niCptAnsOut == _userInp)
                {
                    outText += "：平手.";
                    Label_pssResult.Text = outText;
                }
                    
                else
                {
                    if ((niCptAnsOut == 0) && (_userInp == 2)) {
                        outText += "：你輸了！";
                        Label_pssResult.Text = outText;
                    }
                    else {
                        outText += "：你贏了！";
                        Label_pssResult.Text = outText;
                    }
                }
            }

        }// private void decideResult()

        protected void UserInpPaper(object sender, ImageClickEventArgs e)
        {
            _userInp = 2;

            int niCptAnsOut = _rndCpt.Next(0, 3);
            setCmpPic(niCptAnsOut);
            decideResult(2, niCptAnsOut);

        }

        protected void _ImgBtnUser_scissor_Click(object sender, ImageClickEventArgs e)
        {
            _userInp = 0;
            int niCptAnsOut = _rndCpt.Next(0, 3);
            setCmpPic(niCptAnsOut);
            decideResult(0, niCptAnsOut);

        }

        protected void _ImgBtnUser_stone_Click(object sender, ImageClickEventArgs e)
        {
            _userInp = 1;
            int niCptAnsOut = _rndCpt.Next(0, 3);
            setCmpPic(niCptAnsOut);
            decideResult(1, niCptAnsOut);
        }
        /*            if( (Request.QueryString["number1"] != null) && 
(Request.QueryString["number2"] != null)   )
Label1.Text = ((int.Parse(Request.QueryString["number1"])) +
(int.Parse(Request.QueryString["number2"]))).ToString();*/
    }
}