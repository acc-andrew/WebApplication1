﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // 1. create a session
            if( (Session["logged"] != null) &&  (Convert.ToString(Session["logged"]) == "Yes") )
            {
                Response.Redirect("test2");
            }
            else { 

                if ((Request.Form["userid"] != null) &&
                    (Request.Form["passwd"] != null)    )
                { 
                    if((Request.Form["userid"] == "lccnet") && 
                        (Request.Form["passwd"] == "123456"))
                    {
                        // 2. set session        
                        Application.Lock();
                        Session["login_name"] = _userName.Text;
                        Session["logged"] = "Yes";
                        int nPeople = Convert.ToInt32(Application["cPeople"]) + 1;
                        Application["cPeople"] = nPeople;
                        Application["msgStore"] = new List<string>();
                        Application.UnLock();
                        Response.Redirect("test2");  // 
                        // Response.Redirect("Handler1.ashx");  // 
                    }
                    else
                    {
                        if (Request.Form["userid"] != "lccnet")
                        {
                            _veri_userid.Text = "帳號錯誤！";
                        }
                        else
                        {
                            _veri_userid.Text = "";
                        }
                        if (Request.Form["passwd"] != "123456")
                        {
                            _veri_passwd.Text = "密碼錯誤！";
                        }
                        else
                        {
                            _veri_passwd.Text = "";
                        }
                        // Response.Redirect("http://www.google.com.tw/");
                    }
                }// 

            }// non logged
            

        }// Page_Load


    }
}